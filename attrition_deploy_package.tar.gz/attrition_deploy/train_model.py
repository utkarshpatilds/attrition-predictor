"""
Training script for Employee Attrition Prediction
Trains GradientBoosting + RandomForest, saves the best model + scaler + feature list
"""
import pandas as pd
import numpy as np
import joblib
import json
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, classification_report
)

# ── 1. Load Data ──────────────────────────────────────────────────────────────
df = pd.read_csv("HR_Employee_Attrition.csv")
print(f"Dataset shape: {df.shape}")

# ── 2. Drop Useless Columns ──────────────────────────────────────────────────
drop_cols = ['EmployeeNumber', 'EmployeeCount', 'Over18', 'StandardHours']
df = df.drop(columns=drop_cols)

# ── 3. Encode Target ─────────────────────────────────────────────────────────
df['Attrition'] = df['Attrition'].map({'Yes': 1, 'No': 0})

# ── 4. One-Hot Encode Categorical Columns ────────────────────────────────────
categorical_cols = df.select_dtypes(include='object').columns.tolist()
print(f"Categorical columns: {categorical_cols}")

df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
print(f"Shape after encoding: {df.shape}")

# ── 5. Split Features & Target ───────────────────────────────────────────────
X = df.drop('Attrition', axis=1)
y = df['Attrition']

feature_names = X.columns.tolist()
print(f"Total features: {len(feature_names)}")

# ── 6. Scale Numeric Features ───────────────────────────────────────────────
numeric_cols = X.select_dtypes(include=['int64', 'float64']).columns.tolist()
scaler = StandardScaler()
X[numeric_cols] = scaler.fit_transform(X[numeric_cols])

# ── 7. Train-Test Split ──────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

# ── 8. Train Models ──────────────────────────────────────────────────────────
models = {
    "LogisticRegression": LogisticRegression(max_iter=1000, random_state=42),
    "RandomForest": RandomForestClassifier(
        n_estimators=100, class_weight='balanced', random_state=42, n_jobs=-1
    ),
    "GradientBoosting": GradientBoostingClassifier(
        n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42
    ),
}

results = {}
for name, model in models.items():
    print(f"\nTraining {name}...")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_prob)

    results[name] = {
        "accuracy": acc, "precision": prec, "recall": rec,
        "f1": f1, "roc_auc": auc, "model": model
    }
    print(f"  Accuracy: {acc:.4f} | Precision: {prec:.4f} | Recall: {rec:.4f} | F1: {f1:.4f} | AUC: {auc:.4f}")

# ── 9. Pick Best Model (by F1 — good for imbalanced data) ───────────────────
best_name = max(results, key=lambda k: results[k]['f1'])
best_model = results[best_name]['model']
print(f"\n🏆 Best Model: {best_name} (F1={results[best_name]['f1']:.4f})")

# ── 10. Feature Importance (for best model) ──────────────────────────────────
if hasattr(best_model, 'feature_importances_'):
    importance = pd.DataFrame({
        'feature': feature_names,
        'importance': best_model.feature_importances_
    }).sort_values('importance', ascending=False)
    print("\nTop 10 Important Features:")
    print(importance.head(10).to_string(index=False))

# ── 11. Save Artifacts ───────────────────────────────────────────────────────
joblib.dump(best_model, "best_model.pkl")
joblib.dump(scaler, "scaler.pkl")
joblib.dump(feature_names, "feature_names.pkl")

# Save results summary
summary = {k: {kk: vv for kk, vv in v.items() if kk != 'model'}
           for k, v in results.items()}
summary['best_model'] = best_name
with open("model_results.json", "w") as f:
    json.dump(summary, f, indent=2)

print("\n✅ Model and artifacts saved!")
print("   - best_model.pkl")
print("   - scaler.pkl")
print("   - feature_names.pkl")
print("   - model_results.json")
